package com.example.demo.models;

import jakarta.persistence.Entity;



@Entity
public class Dean extends User{
}
