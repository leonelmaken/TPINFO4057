package com.example.demo.models;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Requete {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idRequete;
    private String filerequete;
    @ManyToMany
    private List<Student> etudiant=new ArrayList<>();
}
